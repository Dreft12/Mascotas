<html>
<head>
<title>ingresar</title>
</head>
<body>
<form methode=get action="modificar2.php">
<label>ingresar el producto amodificar</label>
<input type="text" name="pro"><br>
<label>ingresar el nuevo nombre del producto</label>
<input type="text" name="npro"><br>
<label>ingresar el nuevo valor del producto</label>
<input type="text" name="nval"><br>
<input type="submit" name="enviar">

</form>
</body>
</html>