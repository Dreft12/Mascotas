<html>
<head>
<?php
header ('Content-type: text/html; charset=utf-8');
?>
</head>
<body>
<h1>Selecciones una opción<h1>
<a href="consultar.php">Consultar</a><br>
<a href="ingresar.php">Ingresar</a><br>
<a href="modificar.php">Editar</a><br>
<a href="eliminar.php">Eliminar</a>


</body>

</html>