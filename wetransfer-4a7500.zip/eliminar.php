<htlml>
<head>
<title>eliminar</title>
</head>
<body>
<form methode=get action="eliminar2.php">
<label>ingresar el nombre del producto a elimianr</label>
<input type="text" name="pro"><br>
<input type="submit" name="enviar">

</form>
</body>
</htlml>