<htlml>
<head>
<title>ingresar</title>
</head>
<body>
<form method=get action="ingresar2.php">
<label>ingresar el nombre del producto</label>
<input type="text" name="pro"><br>
<label>ingresar el valor del producto</label>
<input type="text" name="val"><br>
<input type="submit" name="enviar">

</form>
</body>
</htlml>